# Welcome to the AI-Powered Portfolio Website Template!
Dive into a straightforward portfolio website, crafted meticulously with Streamlit. Experience it live and interact with the friendly chatbot right [here](https://portfolio-demo.xs6r134s1i6.us-east.codeengine.appdomain.cloud/)! 

Feel free to interact with the chatbot by typing **“What's her availability”** or **"What is her latest project?"** in the input and observe its response.
![ezgif com-video-to-gif](https://github.com/vicky-playground/portfolio-chat-demo/assets/90204593/59ca859c-d637-4c44-a167-791592882e49)
